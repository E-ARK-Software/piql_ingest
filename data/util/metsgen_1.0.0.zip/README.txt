\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
|||		METs Generation			 |||
///////////////////////////////////////////////////

    Please run genrepmets before genrootmets.

    python genrepmets.py <enter SIP dir>
    python genrootmets.pt <enter SIP dir>

    Directory must be a valid SIP structure.
	
    Package pathlib is not supported by python 2.7


    AGENT INFORMATION
	Must be added manually by opening
	genrepmets.py and genrootmets.py
	in a text editor. The necessary
	input locations can be found at
	the bottom of each file.