================================================================================
  PREMIS Reader & Writer
================================================================================

PREMISRW is a library to help with parsing and creating PREMIS elements.
