import uuid, hashlib, os, subprocess, json, pathlib, datetime, sys

import metsrwrep as metsrw


def gen_sf_filedata():
    print("sf_filedata")
    sf_filedata = {}
    p_records = []
    output = subprocess.Popen(["sf\sf.exe", "-json", directory], stdout=subprocess.PIPE).communicate()[0].decode(
        "utf-8")
    data = json.loads(output)
    for f in data['files']:
        """Use pathlib to get creation and modification time"""
        fname = pathlib.Path(f['filename'])
        creationtime = datetime.datetime.fromtimestamp(fname.stat().st_ctime)
        modificationtime = datetime.datetime.fromtimestamp(fname.stat().st_mtime)
        sf_filedata[str(f['filename']).replace("\\", "/")] = {'created': str(creationtime),
                                                              'filesize': str(f['filesize']),
                                                              'lastmodified': str(modificationtime),
                                                              'mimetype': f['matches'][0]['mime']
                                                              }
        if 'representations\\patient' in f['filename'].lower():
            file_split = f['filename'][len(root_directory + "\\"):].split('\\')
            if file_split[1] not in p_records:
                p_records.append(file_split[1])
    return sf_filedata, p_records


def get_checksum(file):
    sha256_hash = hashlib.sha256()
    with open(file, "rb") as f:
        for byte_block in iter(lambda: f.read(4096), b""):
            sha256_hash.update(byte_block)
    return sha256_hash.hexdigest()


def new_fse(_directory, _record):
    """
        Recursive call to create File System Entry objects for directories
        and files/items and return FSE object
    """
    dir_list = _directory[len(root_directory + "/"):].split('/')
    filegrp_use = dir_list[0].capitalize()  # Used to set filegrp use
    nonroot_dir = _directory[len(root_directory + "/"):]
    fse_dir = metsrw.FSEntry(label=_directory, path=nonroot_dir, type="Directory", file_uuid=str(uuid.uuid4()))

    for file in os.listdir(_directory):
        file_directory = _directory + "/" + file
        # nonroot_file_dir = nonroot_dir + "/" + file
        if not os.path.isdir(file_directory):
            # Removed in order to only present files from the representations folder down
            # if filegrp_use == "Documentation" or filegrp_use == "Schemas" or (
            #        filegrp_use == "Representations" and len(dir_list) >= 4 and dir_list[2] == "data"):
            if filegrp_use == "Representations" and len(dir_list) >= 4 and dir_list[2] == "data":
                file_dict = filedata[file_directory]
                if filegrp_use == "Representations":
                    filegrp_use = dir_list[0] + "/" + dir_list[1] + "/" + dir_list[2]
                    filegrp_use = dir_list[2]
                fse_dir.children.append(metsrw.FSEntry(label=_directory,
                                                       path=nonroot_dir[len("/representations/"+_record):] + "/" + file,
                                                       type="Item",
                                                       file_uuid=str(uuid.uuid4()),
                                                       # file_uuid=str(metsrw.IdGenerator("file")),
                                                       use=filegrp_use,
                                                       checksum=get_checksum(file_directory),
                                                       checksumtype="SHA-256",
                                                       derived_from=fse_dir,
                                                       mimetype=file_dict['mimetype'],
                                                       filesize=file_dict['filesize'],
                                                       created=file_dict['lastmodified'],  # use last_modified
                                                       # lastmodified=file_dict['lastmodified']
                                                       ))
        elif 'representations/' in file_directory:
            if _record in file_directory:
                fse_dir.children.append(new_fse(file_directory, _record))
        else:
            fse_dir.children.append(new_fse(file_directory, _record))
    return fse_dir


def add_dmdsec(_record):
    # print("dmdsec")
    """
        find root metadata file and create dmdsec
    """
    for mdfile, key in filedata.items():
        if mdfile.lower().startswith(
                str(root_directory + "/representations/" + _record + "/metadata/descriptive").lower()):
            fse.add_dmdsec(mdfile[len(root_directory + "/representations/" + _record + "/"):], "OTHER", mode='mdref', loctype="URL",
                           othermdtype="FHIR.Patient",
                           # xlink:type="simple",
                           mimetype=key['mimetype'],
                           size=key['filesize'],
                           created=key['lastmodified'],
                           # lastmod=mets_pl_modified,
                           checksum=get_checksum(mdfile),
                           checksumtype="SHA-256"
                           )
            print("DMDsec Added")


def add_altid():
    # print("AltID")
    for mdfile, key in filedata.items():
        if mdfile.lower().startswith(str(root_directory + "/documentation/submissionagreement").lower()):
            mets.alternate_ids.append(
                metsrw.AltRecordID(str(mdfile[len(root_directory + "/"):]), type="SUBMISSIONAGREEMENT"))
            print("AltId Added")


if __name__ == '__main__':

    # Ensure directory exists
    # TODO ensure directory is compliant SIP structure
    # while True:
    # directory = input("Insert Information Package Directory: ")
    if len(sys.argv[1:]) == 1:
        if os.path.isdir(sys.argv[1]):
            directory = sys.argv[1].replace("\\", "/")
            #break
        else:
            print("Directory not found")
            sys.exit()
    else:
        print("Enter SIP Directory")
        sys.exit()

    root_directory = directory

    # Gather required data from Siegfried etc into dict
    # patient records - list of unique patient record ids
    filedata, patientrecords = gen_sf_filedata()
    print(patientrecords)

    # Generate representation METs for each patient record
    # Each file written to associating patient record file
    for record in patientrecords:
        fse = new_fse(directory, record)
        add_dmdsec(record)

        mets = metsrw.METSDocument()
        mets.OBJID = record
        mets.append(fse)
        add_altid()

        # TODO take agent information as input
        mets.agents.append(
            metsrw.Agent("CREATOR", type="SOFTWARE", name="piql eHealth SIP Creator", notes=["INSERT SOFTWARE VERSION"],
                         csip_notetype="SOFTWARE VERSION"))
        # mets.agents.append(
        #    metsrw.Agent("CREATOR", type="ORGANIZATION", name="INSERT PRODUCER ORGANISATION NAME", notes=["ID: 12345"],
        #                 csip_notetype="IDENTIFICATION CODE"))
        # mets.agents.append(
        #    metsrw.Agent("SUBMITTER", type="INDIVIDUAL", name="SUBMITTING AGENT", notes=["SUBMITTING AGENT DETAILS"]))

        mets.objid = record
        mets.write(root_directory + "/representations/" + record + "/mets.xml", pretty_print=True)
        print(record + " written")
