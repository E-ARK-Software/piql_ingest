\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
|||		METs Generation			 |||
///////////////////////////////////////////////////

    Please run genrepmets before genrootmets.

    python genrepmets.py <enter SIP dir>
    python genrootmets.pt <enter SIP dir>

    Directory must be a valid SIP structure.
	
    Package pathlib is not supported by python 2.7